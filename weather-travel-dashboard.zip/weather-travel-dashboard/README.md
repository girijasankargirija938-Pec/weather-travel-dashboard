# Smart Weather & Travel Dashboard

Search any city -> see live weather, 5-day forecast, weather icons and travel suggestions.
Tech: HTML5, CSS3, ES6+ JavaScript, fetch + async/await, Open-Meteo API (no API key needed).

## Run locally
1. Open the folder in VS Code
2. Install the "Live Server" extension, right-click index.html -> Open with Live Server
   (double-clicking index.html also works; an internet connection is required)

## Git & GitHub (step by step)
    git init
    git add .
    git commit -m "Initial commit: weather dashboard"
    git branch -M main
    git remote add origin https://github.com/<your-username>/weather-travel-dashboard.git
    git push -u origin main
Tip: make several small commits (e.g. "add API code", "add forecast UI", "add travel tips")
so your repository shows your progress.

## Deploy (free)
- GitHub Pages: repo -> Settings -> Pages -> Source: main branch / root -> Save
- or drag the folder onto https://app.netlify.com/drop

Read UNDERSTANDING.md to learn how everything works.
