// ui.js - everything that changes what you SEE on the page (DOM work).

const messageEl = document.getElementById("message");
const currentEl = document.getElementById("current");
const forecastSection = document.getElementById("forecast-section");
const forecastEl = document.getElementById("forecast");
const travelSection = document.getElementById("travel-section");

function showMessage(text, isError = false) {
  messageEl.textContent = text;
  messageEl.classList.toggle("error", isError);
  messageEl.classList.remove("hidden");
}

function hideResults() {
  [currentEl, forecastSection, travelSection].forEach((el) => el.classList.add("hidden"));
}

function showCurrentWeather(location, current) {
  const info = describeWeather(current.weather_code);

  currentEl.innerHTML = `
    <div class="current-main">
      <div class="big-icon">${info.icon}</div>
      <div>
        <h2>${location.name}, ${location.country}</h2>
        <p class="temp">${Math.round(current.temperature_2m)}°C</p>
        <p>${info.text}</p>
      </div>
    </div>
    <div class="details">
      <div>Feels like<strong>${Math.round(current.apparent_temperature)}°C</strong></div>
      <div>Humidity<strong>${current.relative_humidity_2m}%</strong></div>
      <div>Wind<strong>${current.wind_speed_10m} km/h</strong></div>
    </div>`;
  currentEl.classList.remove("hidden");

  // Change the page background to match the weather (CSS class swap)
  document.body.className = `theme-${info.type}`;
}

function showForecast(daily) {
  // .map() turns each day's data into a card, .join("") joins them into one string
  forecastEl.innerHTML = daily.time
    .map((date, i) => {
      const info = describeWeather(daily.weather_code[i]);
      return `
        <div class="day card">
          <p class="day-name">${getDayName(date)}</p>
          <p class="day-icon">${info.icon}</p>
          <p>${Math.round(daily.temperature_2m_max[i])}° / ${Math.round(daily.temperature_2m_min[i])}°</p>
          <p class="rain">Rain ${daily.precipitation_probability_max[i]}%</p>
        </div>`;
    })
    .join("");
  forecastSection.classList.remove("hidden");
}

function showTravel({ summary, tips }) {
  document.getElementById("travel-summary").textContent = summary;
  document.getElementById("travel-list").innerHTML = tips.map((tip) => `<li>${tip}</li>`).join("");
  travelSection.classList.remove("hidden");
}

function showRecent(cities) {
  const box = document.getElementById("recent");
  box.innerHTML = cities.map((c) => `<button type="button" class="chip" data-city="${c}">${c}</button>`).join("");
}
