// weatherInfo.js - converts the weather "code" number from the API into
// an icon, a description and a category.

// Table of codes from the Open-Meteo documentation (grouped to keep it short)
function describeWeather(code) {
  if (code === 0) return { icon: "☀️", text: "Clear sky", type: "clear" };
  if (code <= 2) return { icon: "🌤️", text: "Partly cloudy", type: "clouds" };
  if (code === 3) return { icon: "☁️", text: "Overcast", type: "clouds" };
  if (code === 45 || code === 48) return { icon: "🌫️", text: "Foggy", type: "fog" };
  if (code >= 51 && code <= 57) return { icon: "🌦️", text: "Drizzle", type: "rain" };
  if (code >= 61 && code <= 67) return { icon: "🌧️", text: "Rain", type: "rain" };
  if (code >= 71 && code <= 77) return { icon: "❄️", text: "Snow", type: "snow" };
  if (code >= 80 && code <= 82) return { icon: "🌧️", text: "Rain showers", type: "rain" };
  if (code >= 85 && code <= 86) return { icon: "🌨️", text: "Snow showers", type: "snow" };
  if (code >= 95) return { icon: "⛈️", text: "Thunderstorm", type: "storm" };
  return { icon: "🌡️", text: "Unknown", type: "clouds" };
}

// Short day name from a date string like "2026-10-08"
function getDayName(dateString) {
  return new Date(dateString).toLocaleDateString("en-US", { weekday: "short" });
}
