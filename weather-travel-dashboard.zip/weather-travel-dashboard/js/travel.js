// travel.js - the "smart" part. Looks at weather + temperature and
// returns advice. It is just if/else rules, easy to change.

function getTravelSuggestions(current, daily) {
  const { type } = describeWeather(current.weather_code);
  const temp = current.temperature_2m;
  const tips = [];
  let summary = "";

  // Rule 1: based on the weather type right now
  if (type === "clear") {
    summary = "Great weather for outdoor plans.";
    tips.push("Visit a beach, park or viewpoint.", "Try a city walking tour or photography trip.");
  } else if (type === "clouds") {
    summary = "Comfortable and mild. Good for sightseeing.";
    tips.push("Explore forts, temples or monuments.", "A good day for a cycling or road trip.");
  } else if (type === "rain") {
    summary = "Rainy conditions. Plan indoor activities.";
    tips.push("Visit a museum, mall or art gallery.", "Enjoy a cafe or local food tour.", "Carry an umbrella and avoid hill roads.");
  } else if (type === "snow") {
    summary = "Snowy. Great for winter activities if you are prepared.";
    tips.push("Try skiing or a snow trek with a guide.", "Check road conditions before driving.");
  } else if (type === "storm") {
    summary = "Thunderstorm warning. Stay safe indoors.";
    tips.push("Avoid beaches, open grounds and long drives.", "Postpone outdoor trips until it clears.");
  } else {
    summary = "Low visibility. Travel carefully.";
    tips.push("Delay early-morning drives.", "Indoor attractions are a safer choice.");
  }

  // Rule 2: based on temperature
  if (temp >= 35) tips.push("Very hot: drink plenty of water, wear light cotton clothes, avoid midday outings.");
  else if (temp <= 10) tips.push("Cold: pack warm jackets, gloves and a cap.");

  // Rule 3: look ahead at the next days
  const rainyDays = daily.precipitation_probability_max.filter((p) => p >= 60).length;
  if (rainyDays >= 2) tips.push(`Rain likely on ${rainyDays} of the next 5 days. Keep flexible plans.`);
  else tips.push("Next 5 days look mostly dry. Good time to plan a trip.");

  return { summary, tips };
}
