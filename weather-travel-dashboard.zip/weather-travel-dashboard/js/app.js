// app.js - the "brain": connects the form, the API, and the UI.

const form = document.getElementById("search-form");
const input = document.getElementById("city-input");
const recentBox = document.getElementById("recent");

// Recent searches are remembered using localStorage (the browser's small storage)
let recentCities = JSON.parse(localStorage.getItem("recentCities")) || [];

function saveRecent(city) {
  // Remove duplicates, add the new city at the front, keep only 5
  recentCities = [city, ...recentCities.filter((c) => c !== city)].slice(0, 5);
  localStorage.setItem("recentCities", JSON.stringify(recentCities));
  showRecent(recentCities);
}

// Main function: runs when the user searches
async function searchCity(cityName) {
  if (cityName.trim() === "") {
    showMessage("Please type a city name.", true);
    return;
  }

  hideResults();
  showMessage("Loading weather...");

  try {
    const location = await getCityLocation(cityName);                         // step 1
    const weather = await getWeather(location.latitude, location.longitude);  // step 2

    showCurrentWeather(location, weather.current);
    showForecast(weather.daily);
    showTravel(getTravelSuggestions(weather.current, weather.daily));
    saveRecent(location.name);
    messageEl.classList.add("hidden");
  } catch (error) {
    // Runs for: city not found, no internet, API down
    hideResults();
    showMessage(error.message || "Something went wrong. Check your internet.", true);
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  searchCity(input.value);
});

// Clicking a recent-city button searches again
recentBox.addEventListener("click", (event) => {
  const city = event.target.dataset.city;
  if (city) {
    input.value = city;
    searchCity(city);
  }
});

// When the page opens: show saved cities, and reload the last one
showRecent(recentCities);
if (recentCities.length > 0) searchCity(recentCities[0]);
