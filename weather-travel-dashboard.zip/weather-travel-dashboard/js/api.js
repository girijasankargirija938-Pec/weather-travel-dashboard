// api.js - talks to the internet (Open-Meteo API). No API key needed.

const GEO_URL = "https://geocoding-api.open-meteo.com/v1/search";
const WEATHER_URL = "https://api.open-meteo.com/v1/forecast";

// Step 1: city name -> latitude and longitude
async function getCityLocation(cityName) {
  const response = await fetch(`${GEO_URL}?name=${encodeURIComponent(cityName)}&count=1`);
  if (!response.ok) throw new Error("Could not reach the location service.");

  const data = await response.json();
  if (!data.results || data.results.length === 0) {
    throw new Error(`City "${cityName}" not found. Check the spelling.`);
  }

  // Object destructuring: pick only the fields we need
  const { name, country, latitude, longitude } = data.results[0];
  return { name, country, latitude, longitude };
}

// Step 2: latitude and longitude -> weather data
async function getWeather(latitude, longitude) {
  const params = new URLSearchParams({
    latitude,
    longitude,
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
    timezone: "auto",
    forecast_days: 5
  });

  const response = await fetch(`${WEATHER_URL}?${params}`);
  if (!response.ok) throw new Error("Could not load weather data.");
  return response.json();
}
