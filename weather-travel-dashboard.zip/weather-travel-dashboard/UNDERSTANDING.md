# Understanding This Project (What, Why, How)

## 1. What does the app do?
1. You type a city name.
2. The app asks an API for that city's location, then for its weather.
3. It shows current weather, a 5-day forecast, an icon, and travel advice.
4. The page background changes with the weather (sunny = orange, rain = dark blue).

## 2. Files and their jobs
| File | Job | Why separate? |
|---|---|---|
| index.html | Page structure (search box, empty sections) | HTML = structure only |
| css/style.css | Colours, layout, mobile design | CSS = looks only |
| js/api.js | Fetches data from the internet | If the API changes, only this file changes |
| js/weatherInfo.js | Turns weather code into icon + text | Keeps data-conversion in one place |
| js/travel.js | Travel advice rules | The "smart" logic is easy to find and edit |
| js/ui.js | Writes results onto the page | All DOM code together |
| js/app.js | Connects everything, handles events | The "controller" or brain |

Separating code like this is called **separation of concerns**. Each file has one job, so it is easier to read, fix and share in a team.

## 3. How data flows
```
User types "Chennai" -> app.js (form submit)
   -> api.js getCityLocation()  -> latitude, longitude
   -> api.js getWeather()       -> temperature, code, forecast
   -> ui.js shows weather + forecast
   -> travel.js makes advice -> ui.js shows it
```
Script order in index.html matters: api -> weatherInfo -> travel -> ui -> app.

## 4. What is an API?
A web address that returns data instead of a web page. We use **Open-Meteo** because it is free and needs no signup or API key.
- Geocoding API: city name -> latitude and longitude
- Forecast API: latitude and longitude -> weather
The response is **JSON**, which JavaScript turns into objects with `response.json()`.

## 5. Asynchronous programming (the key skill)
Fetching from the internet takes time (maybe 1 second). JavaScript must not freeze the page while waiting.
- `fetch(url)` starts the request and returns a **Promise** (a "I'll give you the result later" object).
- `await` pauses *inside that function only* until the Promise finishes.
- `async` marks a function that uses `await`.
- `try...catch` handles failures (no internet, city not found) so the app shows a friendly message instead of breaking.

Why two awaits in a row in app.js? The second request needs the latitude/longitude from the first.

## 6. ES6+ features used (mention these in your viva)
| Feature | Example | Where |
|---|---|---|
| const / let | `const form = ...` | everywhere |
| Arrow functions | `(c) => c !== city` | app.js, ui.js |
| Template literals | `` `${name}, ${country}` `` | ui.js, api.js |
| Destructuring | `const { name, country } = data.results[0]` | api.js |
| Spread operator | `[city, ...recentCities]` | app.js |
| Default parameters | `showMessage(text, isError = false)` | ui.js |
| Array methods | `.map() .filter() .slice() .join()` | ui.js, app.js |
| async / await, Promises | `await fetch(...)` | api.js, app.js |
| Modern APIs | `URLSearchParams`, `localStorage` | api.js, app.js |

## 7. Features -> Where implemented
- **City search**: `#search-form` in index.html + `searchCity()` in app.js
- **Weather forecast**: `getWeather()` (api.js) + `showForecast()` (ui.js)
- **Dynamic weather icons**: `describeWeather()` in weatherInfo.js (weather code -> emoji)
- **Travel suggestions**: `getTravelSuggestions()` in travel.js
- **Responsive UI**: flexible grid + `@media (max-width: 650px)` in style.css
- **Extra**: recent searches saved in localStorage, weather-based background theme, error handling

## 8. How travel suggestions work
Three simple rules in travel.js:
1. Weather type (clear, rain, storm...) -> activity ideas
2. Temperature (>= 35 hot, <= 10 cold) -> clothing/safety tip
3. Next 5 days: if 2+ days have rain chance >= 60%, warn the user

## 9. Easy things to try (to learn by changing)
- Add a new rule in travel.js (e.g. wind > 40 km/h -> "avoid boat trips")
- Change theme colours in style.css
- Show 7 days: change `forecast_days: 5` in api.js and the CSS grid columns
- Add a Celsius/Fahrenheit button: F = C x 9/5 + 32

## 10. Likely viva questions
1. **What is the difference between synchronous and asynchronous code?** Sync runs line by line and blocks; async lets other work continue while waiting.
2. **What does `await` do?** Pauses the async function until the Promise resolves.
3. **Why use `try...catch`?** To handle errors like no internet or an unknown city.
4. **Why two API calls?** Weather needs coordinates; the first call converts the city name into coordinates.
5. **What is JSON?** A text format for data that looks like JavaScript objects.
6. **How does the background change?** JS replaces the body's class (`theme-rain`), and CSS styles each class.
7. **How is the site responsive?** Flexbox/grid plus a media query for small screens.
8. **Why is no API key needed?** Open-Meteo is free for non-commercial use. (With OpenWeatherMap you would keep the key secret in a backend.)
9. **What is localStorage?** Small browser storage that survives refresh; used for recent cities.
10. **Git vs GitHub?** Git is the version-control tool on your computer; GitHub is the website hosting repositories.

## 11. Common problems
- "Failed to fetch": no internet, or the API is blocked on college Wi-Fi. Try a mobile hotspot.
- Nothing happens: open the browser console (F12) and read the error.
- City not found: check spelling; try the English name.
